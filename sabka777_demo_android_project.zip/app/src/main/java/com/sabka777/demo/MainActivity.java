package com.sabka777.demo;
import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){
  super.onCreate(b); setContentView(R.layout.activity_main);
  findViewById(R.id.history).setOnClickListener(v -> new AlertDialog.Builder(this)
   .setTitle("Demo History").setMessage("20 Aug 2026 — Open 3 / Close 4\n19 Aug 2026 — Open 7 / Close 1\n18 Aug 2026 — Open 2 / Close 8")
   .setPositiveButton("OK", null).show());
  findViewById(R.id.about).setOnClickListener(v -> new AlertDialog.Builder(this)
   .setTitle("sabka777").setMessage("Educational/demo application using virtual points only. No real-money betting, deposits, withdrawals or cash commissions.")
   .setPositiveButton("OK", null).show());
 }
}
