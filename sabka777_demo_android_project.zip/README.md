# sabka777 Demo
Android demo app using virtual points only.
No real-money betting, deposits, withdrawals, or cash commission functionality.
Open the project in Android Studio and build the debug APK.
